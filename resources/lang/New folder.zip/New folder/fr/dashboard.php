<?php

return array (
  'TOTAL_FORMS_SHARED' => 'TOTAL DE FORMULAIRES PARTAGÉES',
  'TOTAL_ORGANIZATION_USERS' => 'UTILISATEURS TOTAL DE L\'ORGANISATION',
  'dashboard' => 'Tableau de bord',
  'total_trips' => 'voyages totaux',
  'total_users' => 'UTILISATEURS TOTAUX',
);
