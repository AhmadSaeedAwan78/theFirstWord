<?php

return array (
  'home' => 'Domicile',
  'packages' => 'Paquets',
  'users' => 'Utilisatrices',
);
