<?php

return array (
  'email' => 'Courriel',
  'login' => 'Connexion',
  'password' => 'Mot de passe',
);
