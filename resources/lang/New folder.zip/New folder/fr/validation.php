<?php

return array (
  'custom' => 
  array (
    'attribute-name' => 
    array (
      'rule-name' => 'message personnalisé',
    ),
  ),
  'email' => 'L\'attribut doit être une adresse e-mail valide.',
);
