<?php

return array (
  'actions' => 'Actions',
  'add_new' => 'Ajouter nouveau',
  'add_new_packages' => 'Ajouter de nouveaux packages',
  'delete_package' => 'Supprimer le package',
  'delete_package_msg' => 'Etes-vous sûr que vous voulez supprimer?',
  'name' => 'Nom',
  'package' => 'Paquet',
  'packages' => 'paquets',
  'packages_listing' => 'Listes des packages',
  'price' => 'Prix',
  'success_delete' => 'Supprimé',
  'time_period' => 'Période de temps',
  'update' => 'Mettre à jour le package',
);
