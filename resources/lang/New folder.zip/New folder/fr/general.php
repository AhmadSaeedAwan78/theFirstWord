<?php

return array (
  'cancel' => 'Annuler',
  'home' => 'Domicile',
  'logout' => 'Se déconnecté',
  'save' => 'Sauvegarder',
  'search' => 'recherche',
  'site_title' => 'asdasdasda',
  'success_message' => 'Enregistré avec succès!',
);
