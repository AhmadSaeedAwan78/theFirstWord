<?php

return array (
  'confirm_password' => 'Confirmez le mot de passe',
  'password' => 'Mot de passe',
  'reset' => 'Votre mot de passe a été réinitialisé!',
  'reset_password' => 'réinitialiser le mot de passe',
  'reset_password_link' => 'Envoyer le lien de réinitialisation du mot de passe',
  'sent' => 'Nous avons envoyé votre lien de réinitialisation de mot de passe par e-mail!',
  'token' => 'Ce jeton de réinitialisation de mot de passe n\'est pas valide.',
  'user' => 'Nous ne pouvons pas trouver un utilisateur avec cette adresse e-mail.',
);
