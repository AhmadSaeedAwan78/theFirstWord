<?php

return array (
  'TOTAL_FORMS_SHARED' => 'TOTAL FORMS SHARED',
  'TOTAL_ORGANIZATION_USERS' => 'TOTAL ORGANIZATION USERS',
  'dashboard' => 'Tableau de bord',
  'total_trips' => 'Total Trips',
  'total_users' => 'Total Users',
);
