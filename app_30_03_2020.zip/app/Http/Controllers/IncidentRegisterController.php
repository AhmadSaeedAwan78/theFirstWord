<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Incident;
use App\Notification;
use App\Friend;
use App\Who;
use App\Where;
use App\Airport;
use App\Message;
use App\Plan;
use App\How;
use App\PasswordSecurity;
use Auth;
use Lang;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use DB;
class IncidentRegisterController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(){
    	$incident_type = DB::table('incident_type')->get();
    	$organization  = User::where('role',4)->get();
    	$user_type = Auth::user()->role;
    	$currentuserid = Auth::user()->id;
    	if ($user_type == 2 || Auth::user()->user_type == 1){
    		$incident_front = Incident::where('organization_id',Auth::user()->client_id)->get();
    	}
    	else {
    		$incident_front = Incident::where('created_by',$currentuserid)->get();

    	}
    	$incident_register = Incident::get();

    	return view('admin.incident.index',compact('incident_register','user_type','incident_front'));
    }

    public function create()
	{
		$incident_type = DB::table('incident_type')->get();
		$organization  = User::where('role',4)->get();
		$user_type = Auth::user()->role;
		return view('admin.incident.add',compact('incident_type', 'organization','user_type'));
	}

	public function add(Request $request){
        $update = 0;
        if($request->id){
    		$incident = Incident::find($request->id);
			$update  = 1;			
    	}else{
    		 $incident = new Incident;
    	}
    	$currentuserid = Auth::user()->id;
		try{
			$incident->incident_type = $request->incident_type;
			$incident->organization_id = $request->organization_id;
			$incident->name = $request->name;
			$incident->assignee = $request->assignee;
			$incident->description = $request->description;
			$incident->date_occurred = date('Y-m-d', strtotime($request->date_occurred));
			$incident->time_occured = $request->time_occured;
			$incident->date_discovered = date('Y-m-d', strtotime($request->date_discovered));
			$incident->time_discovered = $request->time_discovered;
			$incident->deadline_date = date('Y-m-d', strtotime($request->deadline_date));
			$incident->time_deadline = $request->time_deadline;
			$incident->root_cause = $request->root_cause;
                        $incident->resolution = $request->resolution;
			if($update  == 1){  
               $incident->updated_by = $currentuserid;
			} else{

			$incident->created_by = $currentuserid; }
			
			$success = $incident->save();
			if ($success) {
				if($update  == 1){
				\Session::flash('success', 'Your Incident Update   Successfully');
			   }
			   else {
                   \Session::flash('success', 'Your Incident Save   Successfully');
			   }
				return redirect('incident');
			}
			else{
				\Session::flash('error', 'Your Incident Cannot added Please tryagain later');
				return redirect('add_inccident');
				
			}

		}catch (\Exception $e) {
			echo $e->getMessage();
			exit();
			return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
		}
	}


	 public function edit_incident($id){
	 	$data = Incident::find($id);
	 	$incident_type = DB::table('incident_type')->get();
		$organization  = User::where('role',4)->get();
		$user_type = Auth::user()->role;
		return view('admin.incident.edit',compact('incident_type', 'organization','data','user_type'));

	 }


	 public function destroy(Request $request) 
    { 
        $id = $request->input("id");
      
        
        Incident::where("id", $id)->delete();
       
    }

	

}