<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
// use Mail;
use App\PasswordSecurity;

class Reports extends Controller
{
    public function __construct()
    {

        //  $fa=PasswordSecurity::where('user_id',Auth::user()->id)->first();
        // if($fa && $fa->google2fa_enable==0){
        //   return  redirect('/2fa');
        // }

      //$this->middleware(['auth','2fa']);
   
    }

	public function response_reports_external_users ($category_id)
	{	
		/*
			// get external user form response
			SELECT *, forms.title as form_title 
			FROM  questions
            JOIN  external_users_filled_response ON questions.id            = external_users_filled_response.question_id
            JOIN  external_users_forms           ON external_users_forms.id =   external_users_filled_response.external_user_form_id      
			JOIN  users                          ON users.id                = external_users_forms.client_id    
            JOIN  forms                          ON forms.id                = external_users_filled_response.form_id     
            WHERE questions.question_category = 1		
		*/			
		
		//echo $category_id;exit;

		$response_ques = DB::table('questions')
                          ->join('external_users_filled_response', 'questions.id',    '=', 'external_users_filled_response.question_id')
					      ->join('external_users_forms', 'external_users_forms.id',   '=', 'external_users_filled_response.external_user_form_id')
					      ->join('users',      'users.id',                            '=', 'external_users_forms.client_id')
                          ->join('forms',      'forms.id',                            '=', 'external_users_filled_response.form_id')
					      ->where('questions.question_category', '=', $category_id)  
                          ->select('*', 
					              'forms.title as form_title', 
								  'external_users_filled_response.created as time');
				
	
		//$form_info = DB::table('forms');
		
		if (Auth::user()->role == 1)
		{
			$user_type = 'admin';
			$response_ques = $response_ques->get();
		}
		else
		{
			$user_type = 'client';
			$client_id = Auth::user()->client_id;

			//$client_id = Auth::id();
// 			if (Auth::user()->user_type == 1) 
// 			{
// 			    $client_id = Auth::user()->client_id;
// 			}
			
			
			$response_ques = $response_ques->where('external_users_forms.client_id', '=', $client_id)->get();
		}
		
		if ($category_id == 1)
		{
			$heading = 'Asset Reports (External Users)';
		}
		else
		{
			$heading = 'Data Inventory Reports (External Users)';
		}
		
// 		echo "<pre>";
// 		print_r($response_ques);
// 		echo "</pre>";
// 		exit;
		
		return view('response_reports', ['response_reports' => $response_ques, 'heading' => $heading, 'user_type' => $user_type]);

	}
	
	public function response_reports_registered_users ($category_id)
	{			
		/*
			// get internal user form response
			SELECT *, forms.title as form_title, u.email as user_email, c.email as client_email  
			FROM  questions
            JOIN  internal_users_filled_response ON questions.id  = internal_users_filled_response.question_id
            JOIN  user_forms                     ON user_forms.id = internal_users_filled_response.user_form_id      
			JOIN  users as u                     ON u.id          = user_forms.user_id
            JOIN  users as c                     ON c.id          = user_forms.client_id
            JOIN  forms                          ON forms.id      = internal_users_filled_response.form_id     
            WHERE questions.question_category = 2	
		*/

		$response_ques = DB::table('questions')
                          ->join('internal_users_filled_response', 'questions.id',   '=', 'internal_users_filled_response.question_id')
		                  ->join('user_forms', 'user_forms.id',                      '=', 'internal_users_filled_response.user_form_id')
		                  ->join('users as u', 'u.id',                               '=', 'user_forms.user_id')
		                  ->join('users as c', 'c.id',                               '=', 'user_forms.client_id')
                          ->join('forms',      'forms.id',                           '=', 'internal_users_filled_response.form_id')
		                  ->where('questions.question_category',                     '=', $category_id)  
                          ->select('*', 
		                          'forms.title as form_title',
								  'u.email as user_email',
								  'c.email as client_email',
				                  'internal_users_filled_response.created as time');	
	
		//$form_info = DB::table('forms');
		
		if (Auth::user()->role == 1)
		{
			$user_type = 'admin';
			$response_ques = $response_ques->get();
		}
		else
		{
			$user_type = 'client';
// 			$client_id = Auth::id();
			
// 			if (Auth::user()->user_type == 1) 
// 			{
// 			    $client_id = Auth::user()->client_id;
// 			}
			
			$client_id = Auth::user()->client_id;

			$response_ques = $response_ques->where('user_forms.client_id', '=', $client_id)->get();
			
		}
		
		if ($category_id == 1)
		{
			$heading = 'Asset Reports (Organization Users)';
		}
		else
		{
			$heading = 'Data Inventory Reports (Organization Users)';
		}
		
		/* echo "<pre>";
		print_r($response_ques);
		echo "</pre>";
		exit; */
		
		return view('response_reports', ['response_reports' => $response_ques, 'heading' => $heading, 'user_type' => $user_type]);

	}

	public function internal_user_form_report ()
	{
		//$client_id = Auth::id();
		$client_id = Auth::user()->client_id;

		$form_id = 2;
		
// 		if (Auth::user()->role == 3 && Auth::user()->user_type == 1)
// 		{
// 			$client_id = Auth::user()->client_id;
// 		}
		
		$client_id = Auth::user()->client_id;

		
		// get subforms list
		$subform_list = DB::table('sub_forms')
						  ->where('client_id',        $client_id)
						  ->where('parent_form_id',   $form_id)
						  ->select(
								   'id', 
								   'title')
						  ->get()
						  ->toArray();						  
			  
		// get user list			  
		$user_list    = DB::table('users')
						  ->where('client_id', $client_id)
						  ->select(
								  'id',
								  'name')
						  ->get()
						  ->toArray();
						  		  
		// get form data questions
		/*
		SELECT questions.id,questions.question,questions.form_key,questions.type,questions.options,questions.assoc_type
		FROM   questions 
		JOIN   form_questions ON questions.id = form_questions.question_id
		JOIN   forms          ON forms.id     = form_questions.form_id
		WHERE  questions.question_category = 2
		*/	
		
		$data_category = 2;
		$questions = DB::table('questions')
		               ->join('form_questions', 'questions.id',   '=', 'form_questions.question_id')
					   ->join('forms', 'forms.id',                '=', 'form_questions.form_id')
					   ->where('questions.question_category',     '=', $data_category)
					   ->select('questions.id', 
					            'questions.question',
								'questions.form_key',
								'questions.type',
								'questions.options',
								'questions.question_assoc_type')
					   ->orderBy('sort_order')
					   ->get()
					   ->toArray();
		

		$user_responses = DB::table('users')
		                    ->leftjoin('user_forms', 'users.id',       									'=', DB::raw('user_forms.user_id AND user_forms.client_id = '.$client_id))
							->join('sub_forms', 'sub_forms.id',        									'=', 'user_forms.sub_form_id')
					        ->join('forms', 'forms.id',                									'=', 'sub_forms.parent_form_id')
							->join('form_questions', 'forms.id',       									'=', 'form_questions.form_id')
							->join('questions', 'questions.id',       									'=', 'form_questions.question_id')
		                    ->leftjoin(DB::raw('internal_users_filled_response AS iufrq'), 'questions.id',       '=', DB::raw('iufrq.question_id AND sub_forms.id = iufrq.sub_form_id AND users.id = iufrq.user_id'))			
					        ->where('questions.question_category',     '=', $data_category)
							->groupBy('sub_forms.title', 'users.name', 'questions.question')
							->orderBy('form_questions.sort_order')							
					        ->select(
								'sub_forms.id    as subform_id',
								'sub_forms.title as subform_title', 
					            'users.id        as user_id',
								'users.name',
								'sort_order',
								'questions.id as question_id',
								'questions.question_num',
								'questions.form_key',
								'questions.question', 
								'iufrq.question_response',
								'questions.question_assoc_type')//->toSql();
					        ->get()
					        ->toArray();
							
		/* echo "<h1> questions </h1>";
		echo "<pre>";
		//print_r($questions);
		echo "</pre>"; */
		/* 
			echo "<h1> user resp</h1>";
		echo "<pre>";
		print_r($user_responses);
		echo "</pre>"; */
		//exit;
		
		$curr_index = 0;
		
		foreach ($questions as $key => $question)
		{
			while (isset($user_responses[$curr_index]) && $user_responses[$curr_index]->question_id == $question->id)
			{
				//echo "match with response : ".$user_responses[$curr_index]->question_response."<br>";
				if (!empty($user_responses[$curr_index]->question_response))
				{
					$questions[$key]->user_responses[$user_responses[$curr_index]->subform_id]
													[$user_responses[$curr_index]->user_id] = ['response'   => $user_responses[$curr_index]->question_response,
					                                                                           'user_name'  => $user_responses[$curr_index]->name];				
				}
				$curr_index++;
			}
		}
		
		/* echo "curr_index : ".$curr_index."<br>";
		echo "<h1> questions </h1>";
		echo "<pre>";
		//print_r($questions);
		print_r($subform_list);
		echo "</pre>"; */
		//	exit;
	
					   
	/* 	array_map(function ($sub_form) use($questions) {
		   return $sub_form->questions = $questions;
		}, $subform_list); */			   
					   
		/* echo "<h1>Questions</h1>";								
		echo "<pre>";
		print_r($subform_list);
		echo "</pre>"; */

		//exit;
		return view('reports.report', [
			'subform_list'  => $subform_list,
			'questions' 	=> $questions,
			'user_list' 	=> $user_list,
		]);

						
						  								   
		/* return view('reports.internal_user_form_report', [
					'subform_list' => $subform_list, 
					'user_type'    => 'client',
					'user_list'   => $user_list,
					'questions' => $form_info,
		]); */


	}
	
	public function summary_reports ()
	{
// 		$client_id = Auth::id();
		$client_id = Auth::user()->client_id;

		$form_id = 2;
		
		if (Auth::user()->role == 3)
		{
			if (Auth::user()->user_type == 1)
			{
				$client_id = Auth::user()->client_id;
			}
			else
			{
				return abort('404');
			}
			
		}
		
		// get subforms list
		$subform_list = DB::table('sub_forms')
						  ->where('client_id',        $client_id)
						  ->where('parent_form_id',   $form_id)
						  ->select(
								   'id', 
								   'title')
						  ->get()
						  ->toArray();						  
			  
		// get user list			  
		$user_list    = DB::table('users')
						  ->where('client_id', $client_id)
						  ->select(
								  'id',
								  'name')
						  ->get()
						  ->toArray();
						  		  
		// get form data questions
		
		$data_category = 2;
		/*
		SELECT questions.id,questions.question,questions.form_key,questions.type,questions.options,questions.assoc_type
		FROM   questions 
		JOIN   form_questions ON questions.id = form_questions.question_id
		JOIN   forms          ON forms.id     = form_questions.form_id
		WHERE  questions.question_category = 2
		*/	
		
		$questions = DB::table('questions')
		               ->join('form_questions', 'questions.id',   '=', 'form_questions.question_id')
					   ->join('forms', 'forms.id',                '=', 'form_questions.form_id')
					   ->where('questions.question_category',     '=', $data_category)
					   ->select('questions.id', 
					            'questions.question',
								'questions.form_key',
								'questions.type',
								'questions.options',
								'questions.question_assoc_type')
					   ->orderBy('sort_order')
					   ->get()
					   ->toArray();
					   
		
		$user_responses = DB::table('users')
		                    ->leftjoin('user_forms', 'users.id',       									'=', DB::raw('user_forms.user_id AND user_forms.client_id = '.$client_id))
							->join('sub_forms', 'sub_forms.id',        									'=', 'user_forms.sub_form_id')
					        ->join('forms', 'forms.id',                									'=', 'sub_forms.parent_form_id')
							->join('form_questions', 'forms.id',       									'=', 'form_questions.form_id')
							->join('questions', 'questions.id',       									'=', 'form_questions.question_id')
		                    ->leftjoin(DB::raw('internal_users_filled_response AS iufrq'), 'questions.id',       '=', DB::raw('iufrq.question_id AND sub_forms.id = iufrq.sub_form_id AND users.id = iufrq.user_id'))			
					        ->where('questions.question_category',     '=', $data_category)
							->groupBy('sub_forms.title', 'users.name', 'questions.question')
							->orderBy('form_questions.sort_order')							
					        ->select(
								'sub_forms.id    as subform_id',
								'sub_forms.title as subform_title', 
					            'users.id        as user_id',
								'users.name',
								'sort_order',
								'questions.id as question_id',
								'questions.question_num',
								'questions.form_key',
								'questions.question', 
								'iufrq.question_response',
								'questions.question_assoc_type')//->toSql();
					        ->get()
					        ->toArray();
		
		$curr_index = 0;
		
		foreach ($questions as $key => $question)
		{
			while (isset($user_responses[$curr_index]) && $user_responses[$curr_index]->question_id == $question->id)
			{
				//echo "match with response : ".$user_responses[$curr_index]->question_response."<br>";
				if (!empty($user_responses[$curr_index]->question_response))
				{
					$questions[$key]->user_responses[$user_responses[$curr_index]->subform_id]
													[$user_responses[$curr_index]->user_id] = ['response'   => $user_responses[$curr_index]->question_response,
					                                                                           'user_name'  => $user_responses[$curr_index]->name];				
				}
				$curr_index++;
			}
		}
		
		return view('reports.summary_reports', [
			'subform_list'  => $subform_list,
			'questions' 	=> $questions,
			'user_list' 	=> $user_list,			
		]);
	}
	
	// subform wise summary reports
	public function summary_reports_sfw ()
	{
		$client_id = Auth::user()->client_id;
		
		$form_id = 2;
		
		if (Auth::user()->role == 3)
		{
			if (Auth::user()->user_type != 1)
			{
				return abort('404');
			}
		}
		
		// get subforms list and assigned users
		/*
		$subform_list = DB::table('sub_forms')
						  ->where('client_id',        $client_id)
						  ->where('parent_form_id',   $form_id)
						  ->select(
								   'id', 
								   'title')
						  ->get()
						  ->toArray();	
		*/
	
		$subform_list = [];
	
		/*
		SELECT * 
		FROM  `sub_forms`
		LEFT 
		JOIN   user_forms ON sub_forms.id = user_forms.sub_form_id
		JOIN   users      ON users.id     = user_forms.user_id
		WHERE  user_forms.client_id       = 76		
		*/
				
		$subform_in_query = DB::table('sub_forms')
						  ->leftJoin('user_forms', 'sub_forms.id', '=', 'user_forms.sub_form_id')
						  ->join('users',          'users.id',     '=', 'user_forms.user_id')
						  ->where('user_forms.client_id',               $client_id)
						  ->select( '*',
									'sub_forms.id    as subform_id',						  
									'sub_forms.title as title',
									'users.id       as user_id',
									'users.name     as user_name'
								  )
						  ->get()
						  ->toArray();				  
		/*
		SELECT * 
		FROM  `sub_forms`
		LEFT 
		JOIN   external_users_forms ON sub_forms.id = external_users_forms.sub_form_id
		WHERE  external_users_forms.client_id       = 76
		*/				  
						  
	    $subform_ex_query = DB::table('sub_forms')
						  ->leftJoin('external_users_forms', 'sub_forms.id', '=', 'external_users_forms.sub_form_id')
						  ->where('external_users_forms.client_id',               $client_id)
						  ->select( '*',
									'sub_forms.id    as subform_id',						  
									'sub_forms.title as title',
									'external_users_forms.user_email as user_email'
								  )						  
						  ->get()
						  ->toArray();						  
						  
		foreach ($subform_in_query as $subform)
		{
			if (!isset($subform_list[$subform->sub_form_id]['user_list']))
			{
				$subform_list[$subform->sub_form_id] = [
					'id'            => $subform->subform_id,
					'subform_title' => $subform->title,
					'user_list'     => [
											[
												'user_id'   => $subform->user_id,
												'user_name' => $subform->name
											]
					]
				];
			}
			else
			{
				$subform_list[$subform->sub_form_id]['user_list'][] = [
					'user_id'   => $subform->user_id,
					'user_name' => $subform->name
				];
			}
		}
		
		foreach ($subform_ex_query as $subform)
		{
			if (!isset($subform_list[$subform->sub_form_id]['user_list']))
			{
				$subform_list[$subform->sub_form_id] = [
					'id'            => $subform->subform_id,				
					'subform_title' => $subform->title,
					'user_list'     => [
											[
												'user_email' => $subform->user_email
											]
					]
				];
			}
			else
			{
				$subform_list[$subform->sub_form_id]['user_list'][] = [
					'user_email' => $subform->user_email
				];
			}			
		}
		
	/* 	echo "<pre>";
		print_r($subform_list);
		echo "</pre>";
		exit; */ 
		
		/*	  
		// get user list			  
		$user_list    = DB::table('users')
						  ->where('client_id', $client_id)
						  ->select(
								  'id',
								  'name')
						  ->get()
						  ->toArray();
		*/
						  		  
		// get form data questions
		
		$data_category = 2;
		/*
		SELECT questions.id,questions.question,questions.form_key,questions.type,questions.options,questions.assoc_type
		FROM   questions 
		JOIN   form_questions ON questions.id = form_questions.question_id
		JOIN   forms          ON forms.id     = form_questions.form_id
		WHERE  questions.question_category = 2
		*/	
		
		$questions = DB::table('questions')
		               ->join('form_questions', 'questions.id',   '=', 'form_questions.question_id')
					   ->join('forms', 'forms.id',                '=', 'form_questions.form_id')
					   ->where('questions.question_category',     '=', $data_category)
					   ->select('questions.id', 
					            'questions.question',
								'questions.form_key',
								'questions.type',
								'questions.options',
								'questions.question_assoc_type')
					   ->orderBy('sort_order')
					   ->get()
					   ->toArray();
					   
		
		$in_user_responses = DB::table('users')
		                    ->leftjoin('user_forms', 'users.id',       									'=', DB::raw('user_forms.user_id AND user_forms.client_id = '.$client_id))
							->join('sub_forms', 'sub_forms.id',        									'=', 'user_forms.sub_form_id')
					        ->join('forms', 'forms.id',                									'=', 'sub_forms.parent_form_id')
							->join('form_questions', 'forms.id',       									'=', 'form_questions.form_id')
							->join('questions', 'questions.id',       									'=', 'form_questions.question_id')
		                    ->leftjoin(DB::raw('internal_users_filled_response AS iufrq'), 'questions.id',       '=', DB::raw('iufrq.question_id AND sub_forms.id = iufrq.sub_form_id AND users.id = iufrq.user_id'))			
					        ->where('questions.question_category',     '=', $data_category)
							->groupBy('sub_forms.title', 'users.name', 'questions.question')
							->orderBy('form_questions.sort_order')							
					        ->select(
								'sub_forms.id    as subform_id',
								'sub_forms.title as subform_title', 
					            'users.id        as user_id',
								'users.name',
								'sort_order',
								'questions.id as question_id',
								'questions.question_num',
								'questions.form_key',
								'questions.question', 
								'iufrq.question_response',
								'questions.question_assoc_type')//->toSql();
					        ->get()
					        ->toArray();
							
		/*
		SELECT external_users_forms.id, sub_forms.id as subform_id, sub_forms.title, external_users_forms.user_email, sort_order, questions.question_num, questions.question, eufrq.question_response, external_users_forms.form_link
		FROM   external_users_forms
		JOIN   sub_forms                               ON sub_forms.id         = external_users_forms.sub_form_id AND external_users_forms.client_id = 76
		JOIN   forms                                   ON forms.id             = sub_forms.parent_form_id
		JOIN   form_questions                          ON forms.id             = form_questions.form_id
		JOIN   questions                               ON questions.id         = form_questions.question_id
		LEFT
		JOIN   external_users_filled_response AS eufrq ON questions.id         = eufrq.question_id AND external_users_forms.id = eufrq.external_user_form_id
		WHERE  questions.question_category = 2
		GROUP BY sub_forms.title, external_users_forms.user_email, questions.question
		ORDER BY form_questions.sort_order
		*/
		
		$ex_user_responses = DB::table('external_users_forms')
							->join('sub_forms', 'sub_forms.id',        									'=', 'external_users_forms.sub_form_id')
					        ->join('forms', 'forms.id',                									'=', 'sub_forms.parent_form_id')
							->join('form_questions', 'forms.id',       									'=', 'form_questions.form_id')
							->join('questions', 'questions.id',       									'=', 'form_questions.question_id')
		                    ->leftjoin(DB::raw('external_users_filled_response AS eufrq'), 'questions.id',       '=', DB::raw('eufrq.question_id AND external_users_forms.id = eufrq.external_user_form_id'))			
					        ->where('questions.question_category',     '=', $data_category)
							->groupBy('sub_forms.title', 'external_users_forms.user_email', 'questions.question')
							->orderBy('form_questions.sort_order')							
					        ->select(
								'sub_forms.id    as subform_id',
								'sub_forms.title as subform_title',
								'external_users_forms.user_email as user_email',								
								'sort_order',
								'questions.id as question_id',
								'questions.question_num',
								'questions.form_key',
								'questions.question', 
								'eufrq.question_response',
								'questions.question_assoc_type')//->toSql();
					        ->get()
					        ->toArray();
							
/* 		echo "<h1>In </h1>";					
		echo "<pre>";
		print_r($in_user_responses);
		echo "</pre>";							
							
		echo "<h1>Ex </h1>";					
		echo "<pre>";
		print_r($ex_user_responses);
		echo "</pre>";
		exit;  */

				
		$in_curr_index = 0;
		$ex_curr_index = 0;
		
		foreach ($questions as $key => $question)
		{
			while (isset($in_user_responses[$in_curr_index]) && $in_user_responses[$in_curr_index]->question_id == $question->id)
			{
				if (!empty($in_user_responses[$in_curr_index]->question_response))
				{
					$questions[$key]->user_responses['in'][$in_user_responses[$in_curr_index]->subform_id]
													      [$in_user_responses[$in_curr_index]->user_id] = ['response'   => $in_user_responses[$in_curr_index]->question_response,
					                                                                                       'user_name'  => $in_user_responses[$in_curr_index]->name];				
				}
				
				$in_curr_index++;				
			}
			
			while (isset($ex_user_responses[$ex_curr_index]) && $ex_user_responses[$ex_curr_index]->question_id == $question->id)
			{
				if (!empty($ex_user_responses[$ex_curr_index]->question_response))
				{
					$questions[$key]->user_responses['ex'][$ex_user_responses[$ex_curr_index]->subform_id]
													      [$ex_user_responses[$ex_curr_index]->user_email] = ['response'   => $ex_user_responses[$ex_curr_index]->question_response,
					                                                                                          'user_email' => $ex_user_responses[$ex_curr_index]->user_email];	
				}
				
				$ex_curr_index++;
			}
						
		}
		

//  		echo "<pre>";
// 		print_r($subform_list);
// 		echo "</pre>";
		
// 		echo "<pre>";
// 		print_r($questions);
// 		echo "</pre>";		
		
// 		exit;		
		
		return view('reports.summary_reports2', [
			'subform_list'  => $subform_list,
			'questions' 	=> $questions,
			//'user_list' 	=> $user_list,			
		]);
	}
	
	public function summary_reports_all ()
	{
		$client_id = Auth::user()->client_id;
		$form_id = 2;
		
		if (Auth::user()->role == 3 && Auth::user()->user_type != 1)
		{
			return abort('404');	
		}
		
		// get all unique internal and external users of organization
/* 		$users_list  = DB::select('SELECT DISTINCT external_users_forms.id, user_email as user, "ex" as type 
								   FROM   external_users_forms 
								   WHERE  external_users_forms.client_id = ?
								   UNION
								   SELECT users.id, name as user, "in" as type 
								   FROM   users 
								   JOIN   user_forms 
								   ON     users.id        = user_forms.user_id 
								   WHERE  users.client_id = ?', [$client_id, $client_id]); */

		// get all users with respective subforms
		
		$subject_form_name = DB::table('forms')->where('id', $form_id)->pluck('title')->first();

		$user_form_list = DB::select('SELECT external_users_forms.id, user_email as user, "ex" as type, sub_forms.id as sub_form_id, sub_forms.title as sub_form_title 
										FROM  external_users_forms
										JOIN   sub_forms 
										ON     sub_forms.id = external_users_forms.sub_form_id
										WHERE   external_users_forms.client_id = ? AND sub_forms.parent_form_id = 2
										UNION
										SELECT users.id, name as user, "in" as type, sub_forms.id as sub_form_id, sub_forms.title as sub_form_title 
										FROM   users 
										JOIN   user_forms 
										ON     users.id = user_forms.user_id 
										JOIN   sub_forms 
										ON     sub_forms.id = user_forms.sub_form_id AND sub_forms.parent_form_id = 2
										WHERE  users.client_id = ?', [$client_id, $client_id]);

		$user_count_list = array_count_values(array_column($user_form_list, 'user'));
		array_walk($user_form_list, function (&$user, $index) use($user_count_list) {
			if (isset($user_count_list[$user->user]) && $user_count_list[$user->user] > 1)
			{
				$user->user = $user->user.' '.'(<span class="dept-name">'.$user->sub_form_title.'</span>)';	
			}					
		});
		
//  	    echo "<pre>";
// 		print_r(($user_form_list));
// 		echo "</pre>";
// 		exit;
									  
		
		$data_category = 2;
		/*
		SELECT questions.id,questions.question,questions.form_key,questions.type,questions.options,questions.assoc_type
		FROM   questions 
		JOIN   form_questions ON questions.id = form_questions.question_id
		JOIN   forms          ON forms.id     = form_questions.form_id
		WHERE  questions.question_category = 2
		*/	
		
		$questions = DB::table('questions')
		               ->join('form_questions', 'questions.id',   '=', 'form_questions.question_id')
					   ->join('forms', 'forms.id',                '=', 'form_questions.form_id')
					   ->where('form_questions.form_id',         '=',  $form_id)
					   ->where('questions.question_category',     '=', $data_category)
					   ->select('questions.id', 
					            'questions.question',
								'questions.form_key',
								'questions.type',
								'questions.options',
								'questions.question_assoc_type',
								'sort_order')
					   ->orderBy('sort_order')
					   ->get()
					   ->toArray();
					   
// 		echo "<pre>";
// 		print_r($questions);
// 		echo "</pre>";
// 		exit;
					   
		
		$in_user_responses = DB::table('users')
		                    ->leftjoin('user_forms', 'users.id',       									'=', DB::raw('user_forms.user_id AND user_forms.client_id = '.$client_id))
							->join('sub_forms', 'sub_forms.id',        									'=', 'user_forms.sub_form_id')
					        ->join('forms', 'forms.id',                									'=', 'sub_forms.parent_form_id')
							->join('form_questions', 'forms.id',       									'=', 'form_questions.form_id')
							->join('questions', 'questions.id',       									'=', 'form_questions.question_id')
		                    ->leftjoin(DB::raw('internal_users_filled_response AS iufrq'), 'questions.id',       '=', DB::raw('iufrq.question_id AND sub_forms.id = iufrq.sub_form_id AND users.id = iufrq.user_id'))			
					        ->where('questions.question_category',     '=', $data_category)
					        ->where('form_questions.form_id',         '=',  $form_id)
							->groupBy('sub_forms.title', 'users.name', 'questions.question')
							->orderBy('form_questions.sort_order')							
					        ->select(
								'sub_forms.id    as subform_id',
								'sub_forms.title as subform_title', 
					            'users.id        as user_id',
								'users.name',
								'sort_order',
								'questions.id as question_id',
								'questions.question_num',
								'questions.form_key',
								'questions.question', 
								'iufrq.question_response',
								'questions.question_assoc_type',
								'sort_order')//->toSql();
					        ->get()
					        ->toArray();
							
		/*
		SELECT external_users_forms.id, sub_forms.id as subform_id, sub_forms.title, external_users_forms.user_email, sort_order, questions.question_num, questions.question, eufrq.question_response, external_users_forms.form_link
		FROM   external_users_forms
		JOIN   sub_forms                               ON sub_forms.id         = external_users_forms.sub_form_id AND external_users_forms.client_id = 76
		JOIN   forms                                   ON forms.id             = sub_forms.parent_form_id
		JOIN   form_questions                          ON forms.id             = form_questions.form_id
		JOIN   questions                               ON questions.id         = form_questions.question_id
		LEFT
		JOIN   external_users_filled_response AS eufrq ON questions.id         = eufrq.question_id AND external_users_forms.id = eufrq.external_user_form_id
		WHERE  questions.question_category = 2
		GROUP BY sub_forms.title, external_users_forms.user_email, questions.question
		ORDER BY form_questions.sort_order
		*/
		
		$ex_user_responses = DB::table('external_users_forms')
							->join('sub_forms', 'sub_forms.id',        									'=', 'external_users_forms.sub_form_id')
					        ->join('forms', 'forms.id',                									'=', 'sub_forms.parent_form_id')
							->join('form_questions', 'forms.id',       									'=', 'form_questions.form_id')
							->join('questions', 'questions.id',       									'=', 'form_questions.question_id')
		                    ->leftjoin(DB::raw('external_users_filled_response AS eufrq'), 'questions.id',       '=', DB::raw('eufrq.question_id AND external_users_forms.id = eufrq.external_user_form_id'))			
					        ->where('questions.question_category',     '=', $data_category)
					        ->where('form_questions.form_id',         '=',  $form_id)
							->groupBy('sub_forms.title', 'external_users_forms.user_email', 'questions.question')
							->orderBy('form_questions.sort_order')							
					        ->select(
								'sub_forms.id    as subform_id',
								'sub_forms.title as subform_title',
								'external_users_forms.user_email as user_email',								
								'sort_order',
								'questions.id as question_id',
								'questions.question_num',
								'questions.form_key',
								'questions.question', 
								'eufrq.question_response',
								'questions.question_assoc_type',
								'sort_order')//->toSql();
					        ->get()
					        ->toArray();
							
//  		echo "<h1>In </h1>";					
// 		echo "<pre>";
// 		print_r($in_user_responses);
// 		echo "</pre>";							
							
// 		echo "<h1>Ex </h1>";					
// 		echo "<pre>";
// 		print_r($ex_user_responses);
// 		echo "</pre>";
// 		exit;  

				
		$in_curr_index = 0;
		$ex_curr_index = 0;
		
		foreach ($questions as $key => $question)
		{
			if (trim(strtolower($question->question)) == 'who is the data controller?')
			{
				$questions[$key]->question = 'Data Controller';
			}
			
			if (trim(strtolower($question->question)) == 'who is the data processor?')
			{
				$questions[$key]->question = 'Data Processor';				
			}
			
			while (isset($in_user_responses[$in_curr_index]) && $in_user_responses[$in_curr_index]->question_id == $question->id)
			{
				if (!empty($in_user_responses[$in_curr_index]->question_response))
				{
					$questions[$key]->user_responses['in'][$in_user_responses[$in_curr_index]->subform_id]
													      [$in_user_responses[$in_curr_index]->user_id] = ['response'   => $in_user_responses[$in_curr_index]->question_response,
					                                                                                       'user_name'  => $in_user_responses[$in_curr_index]->name];				
				}
				
				$in_curr_index++;				
			}
			
			while (isset($ex_user_responses[$ex_curr_index]) && $ex_user_responses[$ex_curr_index]->question_id == $question->id)
			{
				if (!empty($ex_user_responses[$ex_curr_index]->question_response))
				{
					$questions[$key]->user_responses['ex'][$ex_user_responses[$ex_curr_index]->subform_id]
													      [$ex_user_responses[$ex_curr_index]->user_email] = ['response'   => $ex_user_responses[$ex_curr_index]->question_response,
					                                                                                          'user_email' => $ex_user_responses[$ex_curr_index]->user_email];	
				}
				
				$ex_curr_index++;
			}
						
		}
		

//  		echo "<pre>";
// 		print_r($user_form_list);
// 		echo "</pre>";
//         echo "<h1>Questions</h1>";		
// 		echo "<pre>";
// 		print_r($questions);
// 		echo "</pre>";		
		
//   		exit;	
		
		return view('reports.summary_reports_all', [
			'user_form_list'  => $user_form_list,
			'questions' 	  => $questions,
			'form_name'       => $subject_form_name
			//'user_list' 	=> $user_list,			
		]);
	}	
		
}
