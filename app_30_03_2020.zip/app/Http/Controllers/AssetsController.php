<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\User;

class AssetsController extends Controller
{
    public function __construct()
    {

   
    }
    
    public function index ()
    {
        $asset_list = DB::table('assets')->whereNotNull('name')->orderBy('name','ASC')->get();
        
        return view('assets.assets', ['asset_list' => $asset_list, 'user_type' => (Auth::user()->role == 1)?('admin'):('client')]);
    }
    
    public function add_asset (Request $request)
    {
        $asset = $request->input('asset');
 
        $status = 'error';
        $title  = 'The asset could not be added';
        $msg    = 'Something went wrong while inserting the asset';      
        
        if (DB::table('assets')->where('name', trim($asset))->exists())
        {
            $status = 'error';
            $title  = 'Duplicate Asset';
            $msg    = 'This asset is already present';
        }
        else
        {
            if (DB::table('assets')->insert(['name' => trim($asset)]))
            {
                $status = 'success';
                $title  = 'Asset Added';
                $msg    = 'This asset is already present';                
            }
        }
 

        return response()->json(['status' => $status, 'title' => $title, 'msg' => $msg]);
    }
    
    public function delete_asset (Request $request)
    {
        $asset_id = $request->input('asset');
        
        $status = 'error';
        $title  = 'Unable to Delete';
        $msg    = 'You are not allowed to perform this operation';        
        
        if (Auth::check() && Auth::user()->role == '1')
        {
            DB::table('assets')->where('id', $asset_id)->delete();
            $status = 'success';
            $title  = 'Removed';
            $msg    = 'The requested asset was successfully removed';            
        }

        return response()->json(['status' => $status, 'title' => $title, 'msg' => $msg]);
    }
}