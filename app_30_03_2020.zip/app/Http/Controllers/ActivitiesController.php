<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\User;

class ActivitiesController extends Controller
{
    public function __construct()
    {

   
    }
    
    public function index ()
    {
        $company_external_users    = DB::table('external_users_forms')->distinct('user_email')->pluck('user_email')->toArray();
        $external_user_activities  = DB::table('external_users_filled_response')
                                       ->selectRaw('*, GROUP_CONCAT(question_response) as merged_responses')
                                       ->whereIn('question_id', DB::table('questions')
                                                                  ->where('question', 'like', '%What activity are you assessing%')->orWhere('question', 'like', '%which department is involved in this activity%')->pluck('id'))
                                       ->whereIn('user_email', $company_external_users)
                                       ->groupBy('external_user_form_id')
//                                       ->distinct('question_response')
                                       ->get();
        // add filter by client id

        $company_internal_users    = DB::table('user_forms')->where('client_id', Auth::user()->client_id)->distinct('id')->pluck('user_id')->toArray();
        $internal_user_activities  = DB::table('internal_users_filled_response')
                                       ->selectRaw('*, GROUP_CONCAT(question_response) as merged_responses')
                                       ->whereIn('question_id', DB::table('questions')
                                                                  ->where('question', 'like', '%What activity are you assessing%')->orWhere('question', 'like', '%which department is involved in this activity%')->pluck('id'))
                                       ->whereIn('user_id', $company_internal_users)
                                       ->groupBy('user_form_id')
//                                       ->distinct('question_response')
                                       ->get();
                                    
        //$activity_list = $internal_user_activities->merge($external_user_activities)->unique();
        $activity_list = $internal_user_activities->merge($external_user_activities);
        
        return view('activities.activities', ['activity_list' => $activity_list, 'user_type' => (Auth::user()->role == 1)?('admin'):('client')]);
    }
}