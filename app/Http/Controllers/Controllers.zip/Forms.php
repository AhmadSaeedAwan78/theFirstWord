<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Mail;
use App\PasswordSecurity;


class Forms extends Controller
{
    public function __construct()
    {
         $fa=PasswordSecurity::where('user_id',Auth::user()->id)->first();
        if($fa->google2fa_enable==0){
            redirect('/2fa');
        }

      //$this->middleware(['auth','2fa']);
      //$this->middleware(['auth']);
      // if (Auth::id() == 2)
      // {

      // }
    }

    // public function admin_site ()
    // {
    //   echo "admin ";
    // }

    /*   
	public function user_site ()
    {
        echo "user site ";
    } 
	*/
	
	
    function view_form ($id = 1)
    {

      // get user form questions
        /*
		SELECT    *
        FROM      forms
        JOIN      form_questions
        ON		  forms.id = form_questions.form_id
        JOIN	  questions
        ON        form_questions.question_id = questions.id
        WHERE     forms.id = 2
        */

        $form_info = DB::table('forms')
                       ->join('form_questions', 'forms.id',   '=', 'form_questions.form_id')
                       ->join('questions',      'form_questions.question_id', '=', 'questions.id')
                       ->where('forms.id', '=', $id)
                       ->select('*')
                       ->get();
					   
					   
/* 	echo "id : ".$id."<br>";

    echo "<pre>";
    print_r($form_info);
    echo "</pre>";
    exit; */



      /*
      SELECT *
      FROM   users
      JOIN   user_forms ON user_forms.user_id = users.id
      WHERE  user_forms.form_link_id = 'wPws9qe8zawIRRVQT7pKLsYqH1LIpzZDFPTctC03'
      */

        return view('forms.view_form', ['questions' => $form_info,
                                  // 'fq_keys'   => $question_keys,
                                  'title'     => !empty($form_info)?($form_info[0]->title):('title'),
                                  'heading'   => !empty($form_info)?($form_info[0]->title):('heading')]);
                                  //'heading'   => $form_link_id]);
    }	


    //
    function show_form ($form_link_id = 'TH7630')
    {

      // get user form questions
        /*
        SELECT    *
        FROM      user_forms
        JOIN 		  sub_forms
        ON			  user_forms.sub_form_id = sub_forms.id
        JOIN      form_questions
        ON			  sub_forms.parent_form_id = form_questions.form_id
        JOIN	    questions
        ON        form_questions.question_id = questions.id
        WHERE     user_forms.form_link_id = 'YUT219'
        */

        $form_info = DB::table('user_forms')
                       ->join('sub_forms',      'user_forms.sub_form_id',     '=', 'sub_forms.id')
                       ->join('form_questions', 'sub_forms.parent_form_id',   '=', 'form_questions.form_id')
                       ->join('questions',      'form_questions.question_id', '=', 'questions.id')
                       ->where('user_forms.form_link_id', '=', $form_link_id)
                       ->select('*',            DB::raw('user_forms.id as uf_id, questions.id as q_id, user_forms.user_id as u_id'))
                       ->get();


        // echo "<pre>";
        // print_r($form_info[0]->expiry_time);
        // echo "</pre>";



        if (strtotime(date('Y-m-d H:i:s')) >= strtotime($form_info[0]->expiry_time))
        {
            return "This link is expired";
        }
        else
        {
        }

        // echo ($form_info[0]->expiry_time)."<br>";
        // echo (date('Y-m-d H:i:s'))."<br>";

        // echo strtotime($form_info[0]->expiry_time)."<br>";
        // echo strtotime(date('Y-m-d H:i:s'))."<br>";

        // exit;

      // fetch already filled info.
      /*
      SELECT *
      FROM  `user_forms`
      JOIN   filled_response ON user_forms.user_id = filled_response.user_id
      WHERE  user_forms.form_link_id = '4ArCLz4WMIgeAevojxabdioUPjLfmFWsiPllt365'
      */

      $filled_info = DB::table('user_forms')
                     ->join('filled_response',      'user_forms.user_id',     '=', 'filled_response.user_id')
                     ->join('questions',      'questions.id',     '=', 'filled_response.question_id')
                     ->where('user_forms.form_link_id', '=', $form_link_id)
                     ->select('question_key', 'question_response', 'question_id', 'additional_comment', 'type')->get();

      $question_key_index = [];

      foreach ($filled_info as $key => $user_response)
      {
          if ($user_response->type == 'mc')
          {
              $user_response->question_response = explode(', ', $user_response->question_response);
          }

          $question_key_index[$user_response->question_key] =
          [
                'question_response' => $user_response->question_response,
                'question_id'       => $user_response->question_id,
                'question_comment'  => $user_response->additional_comment,
                'question_type'     => $user_response->type
          ];
      }
     // echo "<pre>";
     // print_r($question_key_index);
     // echo "</pre>";
     // exit;



      /*
      SELECT *
      FROM   users
      JOIN   user_forms ON user_forms.user_id = users.id
      WHERE  user_forms.form_link_id = 'wPws9qe8zawIRRVQT7pKLsYqH1LIpzZDFPTctC03'
      */

        $user_info = DB::table('users')
                       ->join('user_forms',      'user_forms.user_id',     '=', 'users.id')
                       ->where('user_forms.form_link_id', '=', $form_link_id)
                       ->select('*')->first();


        return view('user_form', ['questions' => $form_info,
                                  'filled'    => $question_key_index,
                                  // 'fq_keys'   => $question_keys,
                                  'user_info' => $user_info,
                                  'title'     => !empty($form_info)?($form_info[0]->title):('title'),
                                  'heading'   => !empty($form_info)?($form_info[0]->title):('heading')]);

        // return view('show_form', ['questions' => $form_info,
        //                           'filled'    => $question_key_index,
        //                           // 'fq_keys'   => $question_keys,
        //                           'user_info' => $user_info,
        //                           'title'     => !empty($form_info)?($form_info[0]->title):('title'),
        //                           'heading'   => !empty($form_info)?($form_info[0]->title):('heading')]);
                                  //'heading'   => $form_link_id]);
    }

    // replaced by generate_subform
    public function submit_form (Request $req)
    {
        $user_form_id = $req->input('form-id');
        $form_link_id = $req->input('form-link-id');
        $user_email   = $req->input('email');
        $user_id      = $req->input('user-id');

        // echo "<pre>";
        // print_r($req->all());
        // echo "</pre>";
        // exit;

        foreach ($req->all() as $post_key => $user_responses)
        {
            if (strpos($post_key, 'q-') !== false)
            {
                if (gettype($user_responses) == 'array')
                {
                    $user_responses = implode(', ', $user_responses);
                }

                $question_field_name = explode('_', $post_key);

                $question_key        = $question_field_name[0];
                $question_id         = $question_field_name[1];

                /*
                INSERT INTO filled_response (cols....)
                VALUES (vals....)
                ON DUPLICATE KEY UPDATE question_response = '$question_response'
                */

                //echo "key: ".$post_key." value: ".$post_val." question_id: ".$question_name[1]."<br>";
                    //
                    // echo "<pre>";
                    // print_r($question_name);
                    // echo "</pre>";

                // DB::insert('insert into filled_response
                // (user_form_id, question_id, question_key, user_id, question_response)
                //  values (?, ?, ?, ?, ?)', [$form_id, $question_id, $question_key, $user_id, $user_responses])->toSql();


                DB::statement('insert into filled_response
                (user_form_id, question_id, question_key, user_id, question_response)
                values (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE question_response = '.'"'.$user_responses.'"', [$user_form_id, $question_id, $question_key, $user_id, $user_responses]);

            }

            if (strpos($post_key, 'c-') !== false)
            {
                $comment_field_name = explode('-', $post_key);

                $comment_key        = $comment_field_name[0];
                $question_id        = $comment_field_name[1];

                if (DB::table('filled_response')->where('question_id', $question_id)->exists())
                {
                    // $form_id      = $req->input('form-id');
                    // $form_link_id = $req->input('form-link-id');
                    // $user_email   = $req->input('email');
                    // $user_id      = $req->input('user-id');

                    DB::table('filled_response')
                      ->where([
                                'user_id'      => $user_id,
                                'user_form_id' => $user_form_id,
                                'question_id'  => $question_id
                              ])
                      ->update(['additional_comment' => $user_responses]);
                }
                else
                {

                }
            }


            //echo "key: ".$post_key." value: ".$post_val." question_id: ".$question_name[1]."<br>";

            // DB::table('sub_forms')->insert([
            //                                   'title'          => $title,
            //                                   'parent_form_id' => $user_form_id,
            //                                   'expiry_time'    => $expiry_time
            //                                ]);
        }


        return view('users.show_msg', ['msg' => 'Your response has been submitted. Thanks ']);
        //print_r($req->all());
    }

    public function forms_list ()
    {

      $this->middleware(['auth','2fa']);

      if (Auth::user()->role != 2)
      {
          return abort(404);
      }

      //$this->middleware(['auth']);


      //$client_id = Auth::id(); // logged in as user

      //echo "client id ".$client_id;

      session(['user_id' => Auth::id()]);

      /*
      SELECT * FROM `forms`
      JOIN users ON users.id = forms.user_id
      */

      $forms_info = DB::table('forms')
                      ->join('users',      'users.id',     '=', 'forms.user_id')
                      ->where('users.id', '=', Auth::id())
                      ->select('title', 'users.id as user_id', 'forms.id as form_id')
                      ->get();

      // echo "<pre>";
      // print_r($forms_info);
      // echo "</pre>";
      // exit;

      // echo session('user_id');

       return view('forms.forms_list', ['forms_list' => $forms_info]);               
    }


    public function subforms_list ($form_id = 1)
    {

      $this->middleware(['auth','2fa']);

      if (Auth::user()->role != 2)
      {
          return abort(404);
      }

        $form_info = DB::table('forms')->find($form_id);
        //$client_id = 1; // logged in as user
        $client_id = Auth::id();
        session(['user_id' => $client_id]);

        $client_user_list = DB::table('users')->where('client_id', '=', session('user_id'))->pluck('name');

        $subforms_list    = DB::table('sub_forms')->where('parent_form_id', '=', $form_id)->get();


        // echo "<pre>";
        // print_r($form_info);
        // echo "</pre>";

        // echo "<pre>";
        // print_r($subforms_list);
        // echo "</pre>";
        // exit;

        return view('subform', [
                                  'title'        => 'Client SubForms',
                                  'heading'      => 'Client SubForms',
                                  'form_info'    => $form_info,
                                  'sub_forms'    => $subforms_list,
                                  'client_users' => $client_user_list
                               ]);
    }


    public function create_subform (Request $req)
    {
      //       if (isset($_POST) && !empty($_POST))
      //       {
      //           print_r($_POST);
      //           exit;
      //       }

      $title       = $req->input('subform_title');
      $form_id     = $req->input('form_id');
      $expiry_time = date('Y-m-d H:i:s', strtotime("+10 days"));

      // echo $expiry_time."<br>";
      // exit;

      $subform_id = DB::table('sub_forms')->insertGetId([
                                      'title'          => $title,
                                      'parent_form_id' => $form_id,
                                      'expiry_time'    => $expiry_time
                                 ]);
								 
	  $this->assign_subform_to_client_users(Auth::id(), $form_id, $subform_id);						 

    }
	
    public function assign_subform_to_client_users ($client_id, $form_id, $subform_id)
    {
        $form_id            = 1;
        //user_id           = 1;
        $user_id            = 'all';

        //$client_id          = Auth::id();
        //$client_id          = 7;

        //if ($req->user_id == 'all')

        $insert_data = [];

        if ($user_id == 'all')
        {
            $client_user_id_list    = DB::table('users')->where('client_id', '=', $client_id)->pluck('id');

            if (!empty($client_user_id_list))
            {
                foreach ($client_user_id_list as $assoc_user_id)
                {
                    $insert_data [] = [
                                          'form_link_id'   => Str::random(40),
                                          'sub_form_id'    => $subform_id,
                                          'user_id'        => $assoc_user_id
                                      ];
                }
            }


            // echo "<pre>";
            // print_r($client_user_id_list);
            // echo "</pre>";
            // get all client's $users

        }
        else
        {
            $insert_data = [
                              'form_link_id'   => Str::random(40),
                              'sub_form_id'    => $sub_form_id,
                              'user_id'        => $user_id
                           ];
        }

        DB::table('user_forms')->insert($insert_data);
		
		/* echo "<pre>";
        print_r($insert_data);
        echo "</pre>";
        exit; */
    }	

    function create_test_user_form ()
    {
        $form_id            = 1;
        $sub_form_id        = 2;
        //user_id           = 1;
        $user_id            = 'all';

        // $client_id          = Auth::id();
        $client_id          = 7;

        //if ($req->user_id == 'all')

        $insert_data = [];

        if ($user_id == 'all')
        {
            $client_user_id_list    = DB::table('users')->where('client_id', '=', $client_id)->pluck('id');

            if (!empty($client_user_id_list))
            {
                foreach ($client_user_id_list as $assoc_user_id)
                {
                    $insert_data [] = [
                                          'form_link_id'   => Str::random(40),
                                          'sub_form_id'    => $sub_form_id,
                                          'user_id'        => $assoc_user_id
                                      ];
                }
            }


            // echo "<pre>";
            // print_r($client_user_id_list);
            // echo "</pre>";
            // get all client's $users

        }
        else
        {
            $insert_data = [
                              'form_link_id'   => Str::random(40),
                              'sub_form_id'    => $sub_form_id,
                              'user_id'        => $user_id
                           ];
        }

        // echo "<pre>";
        // print_r($insert_data);
        // echo "</pre>";
        // exit;

        DB::table('user_forms')->insert($insert_data);
        // echo $expiry_time."<br>";
        // exit;
    }
	
    public function subforms_email_list ($subform_id = 4)
    {
      $this->middleware(['auth','2fa']);

      if (Auth::user()->role != 2)
      {
          return abort(404);
      }

      //$client_user_list = DB::table('users')->where('client_id', '=', session('user_id'))->pluck('name');

      //echo "sub form id : ". $subform_id . "<br>";


      $form_user_list = DB::table('user_forms')
                      ->join('sub_forms',      'sub_forms.id',     '=', 'user_forms.sub_form_id')
                      ->join('users',      'users.id',     '=', 'user_forms.user_id')
                      ->where('sub_form_id', '=', $subform_id)
                      ->select('form_link_id', 'email', 'name', 'title')->get();

      $title = 'User List';
      $heading = 'user list';

   // echo "<pre>";
   //    print_r($form_user_list);
   //    echo "</pre>";
   //    exit;

      //$subforms_list    = DB::table('sub_forms')->where('parent_form_id', '=', $form_id)->get();

      return view('forms.users_send_form_list', compact('form_user_list', 'subform_id', 'title', 'heading'));
   

    }	
	
    public function send_form_link_to_users ($sub_form_id)
    {
      $this->middleware(['auth','2fa']);

      if (Auth::user()->role != 2)
      {
          return abort(404);
      }

      /*
      SELECT *
      FROM  `user_forms`
      JOIN  sub_forms ON sub_forms.id = user_forms.sub_form_id
      JOIN  users     ON users.id     = user_forms.user_id
      WHERE sub_form_id = 4
      */

      $forms_info = DB::table('user_forms')
                      ->join('sub_forms',      'sub_forms.id',     '=', 'user_forms.sub_form_id')
                      ->join('users',      'users.id',     '=', 'user_forms.user_id')
                      ->where('sub_form_id', '=', $sub_form_id)
                      ->select('form_link_id', 'email', 'name', 'title')->get();

   /*    echo "<pre>";
      print_r($forms_info);
      echo "</pre>";
      exit; */

       foreach ($forms_info as $f_info)
       {
         $data = array('name'=> $f_info->name, 'form_link_id' => $f_info->form_link_id);

         Mail::send(['text'=>'test_email'], $data, function($message) use($f_info) {
              $message->to($f_info->email, 'D3G Forms')->subject
                 ($f_info->title);
              $message->from('d3gforms@gmail.com','D3G Forms');

         });
       }
	   
      $msg =  "Forms email Sent. Check your inbox.";
	  
      return view('show_msg', compact('msg'));
	  
        // get form users
    }	





}
