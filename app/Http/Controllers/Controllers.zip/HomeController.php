<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;

use Hash;

use Session;

use App\User;

use App\Cart;

use App\Ticket;

use App\Package;

use App\Faq;

use App\Blog;

use DB;

use Sentinel;
use Rminder;
use Mail;
use App\PasswordSecurity;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth','2fa']);
           $fa=PasswordSecurity::where('user_id',Auth::user()->id)->first();
        if($fa->google2fa_enable==0){
            redirect('/2fa');
        }

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		if (Auth::user()->role == 1)
		{
			//return 'admin redirect';
			return redirect('/admin');

		}
		
		if (Auth::user()->role == 2)
		{
			
			return redirect('/Forms/ClientSite');
			//return 'client redirect';
		}
        return view('home');
    }
	
	public function test ()
	{
		return view('admin.client.test');
	}

    public function custom_login ($company_id)
    {
        //echo "company Id : ".$company_id."<br>";
    }

}
