<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Auth;
use App\Package;
use App\Related_product;
use App\Attibute;
use App\PaksageImage;
use App\Ticket;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use DB;
use Lang;
use Session;
use App\PasswordSecurity;

class PackagesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
           $fa=PasswordSecurity::where('user_id',Auth::user()->id)->first();
        if($fa->google2fa_enable==0){
            redirect('/2fa');
        }

        
    }

    public function index() 
    { 
        $client = User::where('role',2)->get();
		$user = User::where('role',3)->orderBy('id','DESC')->get();
        return view('admin.selectClient.home', compact("user", "client"));
    }
    
    public function edit($id) 
    { 
        $package = Package::find($id);
        $rel_products = Package::select('id','name')->where('id','!=',$id)->get();
        $data = DB::table('competitions')->whereRaw("product_id = $id")->orderBy('winner', 'DESC')->get();
        return view('admin.packages.edit', compact("package","data","rel_products"));
    }

    public function create() 
    { 
        // print_r($id);exit();
        $test = Auth::user()->id;
        return view('admin.packages.form', compact("test"));
    }

    public function store(Request $request) 
    { 
        $user_id = Auth::user()->id;
        $uniqid = uniqid();
    	DB::beginTransaction();
    	if($request->id){
    		$package = Package::find($request->id);
    	}else{
    		 $package = new Package;
             $package->uniqid = $uniqid;
    	}
			try {
			    $package->name = $request->name;
                $package->price = $request->price;
                $package->start_date = date('Y-m-d H:i:s', strtotime($request->start_date));
                $package->max_tickets = $request->max_tickets;
                $package->description = $request->description;
                $package->featured = $request->featured;
                $package->user_id = $user_id;
				$success =  $package->save();
				if($success){

				$id =  $package->id;

                // Insert tickets
                if($request->max_tickets && !$request->id){
                   for ($i=1; $i <= $request->max_tickets ; $i++) { 
                    $ticket= new Ticket;
                    $ticket->user_id= $user_id;
                    $ticket->product_id= $id;
                    $ticket->code= $i;
                    $ticket->date_purchased= date('Y-m-d H:i:s');
                    $ticket->paid_price=$package->price;
                    $ticket->discount= 0;
                    $ticket->purchase_type= 0; // 0 purchased 1 bonus
                    $ticket->status= 0; // 0 available
                    $ticket->save();
                    } 
                }
                

				
			        //Insert attributes
			        if(!empty($request->label) && !empty($request->attribute) ){
				        $labels = $request->label;
				        $attributes = $request->attribute;
				        foreach ($labels as $key=> $lab ) {
				        	if($lab !='' && $attributes[$key] !=''){
				         $attr = new Attibute;
				         $attr->package_id = $id;
				         $attr->label = $lab;
				         $attr->attribute = $attributes[$key];
				         $attr->save();  
				     }
				        }
			        }
				}				
			    DB::commit();
			    $request->session()->forget('product_id');
			} catch (\Exception $e) {
			    DB::rollback();
			    return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
			}
			
            return redirect("packages/edit/$id");
    }


        public function edit_store(Request $request) 
    { 
        $uniqid = uniqid();
        DB::beginTransaction();
        if($request->id){
            $package = Package::find($request->id);
        }else{
             $package = new Package;
             $package->uniqid = $uniqid;
        }
            try {
                $package->name = $request->name;
                $package->price = $request->price;
                $package->start_date = date('Y-m-d H:i:s', strtotime($request->start_date));
                $package->max_tickets = $request->max_tickets;
                $package->description = $request->description;
                $package->featured = $request->featured;
                $success =  $package->save();
                if($success){

                $id =  $package->id;

                // Insert tickets
                if($request->max_tickets && !$request->id){
                   for ($i=1; $i <= $request->max_tickets ; $i++) { 
                    $ticket= new Ticket;
                    $ticket->user_id= 0;
                    $ticket->product_id= $id;
                    $ticket->code= $i;
                    $ticket->date_purchased= date('Y-m-d H:i:s');
                    $ticket->paid_price=$package->price;
                    $ticket->discount= 0;
                    $ticket->purchase_type= 0; // 0 purchased 1 bonus
                    $ticket->status= 0; // 0 available
                    $ticket->save();
                    } 
                }
                

                
                    //Insert attributes
                    if(!empty($request->label) && !empty($request->attribute) ){
                        $labels = $request->label;
                        $attributes = $request->attribute;
                        foreach ($labels as $key=> $lab ) {
                            if($lab !='' && $attributes[$key] !=''){
                         $attr = new Attibute;
                         $attr->package_id = $id;
                         $attr->label = $lab;
                         $attr->attribute = $attributes[$key];
                         $attr->save();  
                     }
                        }
                    }
                }               
                DB::commit();
                $request->session()->forget('product_id');
            } catch (\Exception $e) {
                DB::rollback();
                return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
            }
            
            return redirect("packages/edit/$id");
    }

    public function save_related_product(Request $request) 
    { 
        DB::beginTransaction();
       
            try {
                $products=$request->related_products;
                if(!empty($products) && $request->package_id)
                 Related_product::where('package_id',$request->package_id)->delete();
                foreach ($products as $key => $value) {
                $product= new Related_product;
                $product->package_id = $request->package_id;
                $product->related_product_id = $value;
                $product->save();
                   }
                   DB::commit();
                
            } catch (\Exception $e) {
                DB::rollback();
                return redirect()->back()->withErrors(['error' => $e->getMessage()])->withInput();
            }
            
            return  redirect()->back()->with('success', 'Successfully saved');
    }

     public function add_attribute(Request $request) 
    { 
        if($request->id){
    		$attr = Attibute::find($request->id);
    		$operation='edit';
    	}else{
    		 $attr = new Attibute;
    		 $operation='add';
             
    	}
    			$attr->package_id = $request->package_id;
			    $attr->label = $request->label;
                $attr->attribute = $request->attribute;
				$success =  $attr->save();
				return ['status' =>$success, 'operation' =>$operation, 'data' =>$attr];
				 
    }
    public function edit_attribute(Request $request) 
    { 
      
    		$attribute = Attibute::find($request->id);
		    return $attribute;
    } 
      public function delete_attr(Request $request) 
    { 
            $id=$request->id;
            $attribute=Attibute::find($id);
            $attribute->delete(); 
            echo $id;      
    }

    public function add_package_images(Request $request) 
    { 
    	           $images=[];
				   
			        if($request->hasFile('images'))
			        {
			        	
			        	$id=$request->package_id;
			            $files = $request->file('images');
			            foreach($files as $file)
			            {
			            	$uniqid = uniqid();
			                $ext=$file->getClientOriginalExtension();
			                $name=$uniqid.'.'.$ext;
			                $file->move("products/$id/",$name);
			                $image=array();
			                $image['name']=$name;
			                $image['package_id'] =$id;
			                $inser_id=PaksageImage::insertGetId($image);
			                $img=['url' =>url("products/$id/$name"),'id' =>$inser_id];
			                $images[]=$img;
			            }
			        } 
    		return $images;
    }
            
    public function destroy(Request $request) 
    { 
        $id = $request->input("id");
        Package::where("id", $id)->delete();
        PaksageImage::where("package_id",$id)->delete();
        Ticket::where("product_id",$id)->delete();

    }

    public function listImages()
    {
        $pak_id = Session::get('pak_id');
        // dd($id);
        return view('admin.packages.listImages', compact('pak_id'));
    }

    public function deleteImage(Request $request) 
    { 
    	$ids=$request->id;
    	foreach ($ids as $key => $id) {
    		$img=PaksageImage::find($id);
    		$img->delete();
    		File::delete("products/$img->package_id/$img->name");
    	}
    }

    public function saveClient(Request $request, $id)
    {
        $clientid = Input::get('team');
        // print_r($id);exit();
        User::where('id',$id)->update(['client_id'=> $clientid]);
        return redirect('selectClient')->with('alert','Client linked Successfully');
    }

    public function client()
    {
        $client = User::where('role',2)->get();
        // print_r($client);exit();
        return view('admin.client.home', compact('client'));
    }

    public function showUser($id)
    {
        $user = User::where('client_id',$id)->get(); 
        // print_r($users);exit();
        return view('admin.client.display', compact('user'));
    }

    // public function question()
    // {
    //     $question = DB::table('question')->select('question.*','question_type.question_type','users.name')->join('question_type','question.question_type_id','=','question_type.id')->join('users','question.user_id','=','users.id')->get();
    //     // dd($question);
    //     return view('admin.question.questionForm', compact('question'));
    // }

      public function profile($id)
    {
        // print_r($id);exit();
        $client = DB::table('users')->where('id',$id)->first();
        return view('profile', compact('client'));
    }

    public function profile_edit(Request $request)
    {
        $id = $request->input('id');
        // print_r($file);exit();

       if($request->hasfile('images')){
                $file=$request->file('images');
                $filename = $file->getClientOriginalName();
                $ext=$file->getClientOriginalExtension();
                $imgname=uniqid().$filename;
                $destinationpath=public_path('img');
                $file->move($destinationpath,$imgname);
            }
            else{
                $imgname =$request->profile_image;
            }
            // print_r($imgname);exit();
        $data = array(            
            'name'=>$request->input('name'),
            'email'=>$request->input('email'),
            'company'=>$request->input('company'),
            'password'=>bcrypt($request->input('password')),
            'image_name'=>$imgname
        );
        // print_r($data);exit();
        DB::table('users')->where('id',$id)->update($data);
        // $client = DB::table('users')->where('id',$id)->first();
        // return view('profile', compact('client'));
        return redirect('profile/'.$id);
    }

    public function send_email($id)
    {
        // print_r("expression");exit();
        $client = DB::table('users')->where('id',$id)->first();
        $user = DB::table('users')->where('client_id',$id)->get();
        return view('send_email', compact('user','client'));
    }
    
}
