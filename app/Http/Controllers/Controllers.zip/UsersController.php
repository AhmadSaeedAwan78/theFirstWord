<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Notification;
use App\Friend;
use App\Who;
use App\Where;
use App\Airport;
use App\Message;
use App\Plan;
use App\How;
use App\PasswordSecurity;
use Auth;
use Lang;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\File;
use DB;
class UsersController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
           $fa=PasswordSecurity::where('user_id',Auth::user()->id)->first();
        if($fa->google2fa_enable==0){
            redirect('/2fa');
        }

    }

    public function index() 
    {        
        $users = User::whereIn('role', [2, 3])->get();
        return view('admin.users.home', compact("users"));
    }

    public function detail($id) 
    { 
        $user_data= User::find($id);
        $user_data->package= Package::find($user_data->package_id);
         $rating = DB::table('rating')->where('user_id', $id)->avg('rating');
        if($rating) {
            $user_data->rating = round($rating, 1, PHP_ROUND_HALF_DOWN);
                
        }else{
            $user_data->rating = 0;

        }
        $user_data->package= Package::find($user_data->package_id);
       
         $plans= Plan::where("user_id", $id)->get();
        foreach ($plans as  $plan) {
            $plan_id=$plan->id;
            // $cities = Where::where("plan_id" , $plan_id)->get();
            $peoples = Who::where("plan_id", $plan_id)->get();
            $airports = How::where("plan_id", $plan_id)->get();
            $destinations = DB::table('plan_dates')->where("plan_id", $plan_id)->get();
            $packages = DB::table('plan_packages')->where("plan_id", $plan_id)->get();
            $usersarray = array();
            $airports_array = array();
            $cities= DB::select("select city_name   from airports where id IN (select city_id from plan_where where plan_id= $plan_id ) order by country asc ");

            foreach($airports as $airport) { 
                $airports_array[] = Airport::select("id", "name", "city_name")->where("id", $airport->city_id)->first();
            }

            foreach($peoples as $people) { 
                $usersarray[] = User::select("id", "name")->where("id", $people->user_id)->first();
            }
       
            $destinations = $destinations->toArray();
            foreach ($destinations as $key => $dest) {
                if(empty($dest->departure_date) && empty($dest->arrival_date) ) {
                    unset($destinations[$key]);
                }else{
                    $c = Airport::find($dest->city_id);
                    $dest->name = $c->city_name;
                }
                
            }
            if(count($destinations)) {
                usort(
                    $destinations, function ( $a, $b ) {
                        return strtotime($a->departure_date) - strtotime($b->departure_date);
                    }
                );
            }
            $plan->first = !empty($destinations) ?  reset($destinations)->departure_date:""; ;
            $plan->last = !empty($destinations) ?  end($destinations)->arrival_date:""; ;
         
            $plan->cities = $cities;
            $plan->users = $usersarray;
            $plan->packages = $packages;
            $plan->airports = $airports_array;
            $plan->destinations = $destinations;
        
        }
        $friends = DB::select(" select * from  friends where ( user_id=$id OR sender_id=$id ) and status=1 and type='friend'");
        foreach ($friends as $friend) {
            $sender_id = ($friend->sender_id == $id ) ? $friend->user_id:$friend->sender_id;
            $user = User::find($sender_id);
            $friend->name=$user->name;
            $friend->email=$user->email;
            $file="storage/profiles/" . $id . ".jpg";
            if(file_exists($file)) {
                $friend->photo = url($file."?r=" . rand(0, 100));
            }else{
                $friend->photo="backend/img/avatar-2.jpg";
            }
            

        }
         
          
     
        return view('users.detail', compact("user_data", "friends", 'plans'));
    }

    public function edit($id) 
    { 
        $user = User::find($id);
        return view('admin.users.edit', compact("user"));
    }

    public function addUser() 
    { 
        $client = DB::table('users')->where('role',2)->get();
        return view('admin.users.addUser', compact('client'));
    }

    public function addClient() 
    { 
        // echo "string";exit();
        return view('admin.users.addClient');
    }

    public function store(Request $request) 
    { 
        $clientid = Input::get('team');
        $value = $request['optradio'];
        $any = $request->input('email');
        $test = DB::table('users')->where('email','=',$any)->first();

        if($request->password != $request->rpassword)
                {
            return redirect('users/add')->with('alert', 'Password did not match!')->withInput();
                }
        elseif (empty($test)) {
            $imgname ='';
            if($request->hasfile('images')){
                $file=$request->file('images');
                $filename = $file->getClientOriginalName();
                $ext=$file->getClientOriginalExtension();
                $imgname=uniqid().$filename;
                $destinationpath=public_path('/img');
                $file->move($destinationpath,$imgname);
            }
            // print_r($imgname);exit();
        $data = array(
           "name" => $request->input('name'),
           "email" => $request->input('email'),
           "company"=> $request->input('company'),
           "role" => 3,
           "image_name" => $imgname,
           "client_id" => $clientid,
        );
        if($request->input('password')) { 
            $data['password'] = bcrypt($request->input('password'));
        }


        if($request->input('id')) {
            User::where("id", $request->input("id"))->update($data);
            $insert_id = $request->input("id");
        } else { 
            $insert_id =  User::insertGetId($data);
        }
        \Session::flash('success', Lang::get('general.success_message'));
        return redirect('admin');
        }
        else
        {
            return redirect('admin')->with('alert', 'Email already exists!')->withInput();
            
        }          
    }

    public function clientStore(Request $request) 
    { 
        $value = $request['optradio'];
        $any = $request->input('email');
        $test = DB::table('users')->where('email','=',$any)->first();

        if($request->password != $request->rpassword)
                {
            return redirect('users/add')->with('alert', 'Password did not match!')->withInput();
                }
        elseif (empty($test)) {
            $imgname ='';
            if($request->hasfile('images')){
                $file=$request->file('images');
                $filename = $file->getClientOriginalName();
                $ext=$file->getClientOriginalExtension();
                $imgname=uniqid().$filename;
                $destinationpath=public_path('/img');
                $file->move($destinationpath,$imgname);
            }
            // print_r($imgname);exit();
        $data = array(
           "name" => $request->input('name'),
           "email" => $request->input('email'),
           "company"=> $request->input('company'),
           "role" => 2,
           "image_name" => $imgname,
        );
        if($request->input('password')) { 
            $data['password'] = bcrypt($request->input('password'));
        }


        if($request->input('id')) {
            User::where("id", $request->input("id"))->update($data);
            $insert_id = $request->input("id");
        } else { 
            $insert_id =  User::insertGetId($data);
        }
        \Session::flash('success', Lang::get('general.success_message'));
        return redirect('admin');
        }
        else
        {
            return redirect('admin')->with('alert', 'Email already exists!')->withInput();
            
        }          
    }

    public function edit_store(Request $request , $id) 
    { 
            $data = User::where("id", $request->input("id"))->first();
            $test = $data->image_name;
            // print_r($destinationpath);exit();
            if($request->password != $request->rpassword)
                {
            return redirect('users')->with('alert', 'Password did not match!');
                } 
                else{      
            if($request->hasfile('images')){
                $file=$request->file('images');
                $filename = $file->getClientOriginalName();
                $ext=$file->getClientOriginalExtension();
                $imgname=uniqid().$filename;
                $destinationpath=public_path('img');
                $file->move($destinationpath,$imgname);
            }
            else{
                $imgname =$request->profile_image;
            }
            // print_r($imgname);exit();

            $data = array(
           "name" => $request->input('name'),
           "image_name" => $imgname,
        );
        if($request->input('password')) { 
            $data['password'] = bcrypt($request->input('password'));
        }
        if($request->input('id')) {

            $destinationpath=public_path("img/$test");
            // print_r($destinationpath);exit();
            File::delete($destinationpath);
            User::where("id", $request->input("id"))->update($data);
            $insert_id = $request->input("id");
        } else { 
            $insert_id =  User::insertGetId($data);
        }
            return redirect("/admin");
        }
    }


    
    public function change_status(Request $request) 
    { 
         $data = array(
           "status" => $request->input('status')
          );
         User::where("id", $request->input("id"))->update($data);  
    }

    public function destroy(Request $request) 
    { 
        $id = $request->input("id");
        
        User::where("id", $id)->delete();
       
    }
  
    
}
